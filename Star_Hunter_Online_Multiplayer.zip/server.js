const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true } });
const PORT = process.env.PORT || 3000;
app.use(express.static(__dirname));
app.get("/health", (_req,res) => res.json({ok:true,game:"Star Hunter Online"}));

const rooms = new Map();
const W = 960, H = 600;
const rand = (a,b) => a + Math.random()*(b-a);
const code = () => Math.random().toString(36).slice(2,6).toUpperCase();
function makeRoom(id) {
  return { id, players:new Map(), enemies:[], bullets:[], enemyBullets:[], score:0, wave:1,
    nextEnemy:1, spawnIn:1.2, started:false, created:Date.now() };
}
function safeName(n) { return String(n||"Pilot").replace(/[<>]/g,"").trim().slice(0,16) || "Pilot"; }
function roomFor(socket) { return rooms.get(socket.data.room); }
function publicState(r) {
  return {room:r.id, players:[...r.players.values()].map(p=>({id:p.id,name:p.name,x:p.x,y:p.y,hp:p.hp,color:p.color,score:p.score,alive:p.alive})),
    enemies:r.enemies.map(e=>({id:e.id,x:e.x,y:e.y,r:e.r,hp:e.hp,maxHp:e.maxHp,type:e.type})),
    bullets:r.bullets.map(b=>({id:b.id,x:b.x,y:b.y,owner:b.owner})),
    enemyBullets:r.enemyBullets.map(b=>({id:b.id,x:b.x,y:b.y})), score:r.score,wave:r.wave,started:r.started };
}
function emitState(r) { io.to(r.id).emit("state",publicState(r)); }
function enterRoom(socket, roomId, name) {
  const id = String(roomId||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6);
  if (!id) return socket.emit("notice",{type:"error",text:"اكتب كود الغرفة"});
  let r = rooms.get(id);
  if (!r) { if(socket.data.room) leaveRoom(socket); r=makeRoom(id); rooms.set(id,r); }
  if (r.players.size >= 4) return socket.emit("notice",{type:"error",text:"الغرفة كاملة (4 لاعبين)"});
  if(socket.data.room) leaveRoom(socket);
  const colors=["#64eaff","#ff76ca","#a7ff83","#ffc56b"];
  const p={id:socket.id,name:safeName(name),x:160+r.players.size*180,y:510,hp:100,color:colors[r.players.size%colors.length],score:0,alive:true,
    input:{left:false,right:false,fire:false,boost:false},lastShot:0,boostUntil:0,invuln:0};
  r.players.set(socket.id,p); socket.data.room=id; socket.join(id);
  socket.emit("joined",{room:id,host:r.players.size===1}); io.to(id).emit("notice",{type:"info",text:`${p.name} دخل الغرفة`}); emitState(r);
}
function leaveRoom(socket) {
  const id=socket.data.room, r=rooms.get(id); if(!r)return;
  const p=r.players.get(socket.id); if(p) io.to(id).emit("notice",{type:"info",text:`${p.name} خرج من الغرفة`});
  r.players.delete(socket.id); socket.leave(id); socket.data.room=null;
  if(!r.players.size) rooms.delete(id); else emitState(r);
}
io.on("connection", socket=>{
  socket.on("createRoom",({name}={})=>{let id; do{id=code()}while(rooms.has(id));enterRoom(socket,id,name);});
  socket.on("joinRoom",({room,name}={})=>enterRoom(socket,room,name));
  socket.on("input", data=>{
    const r=roomFor(socket),p=r&&r.players.get(socket.id); if(!p||!data||typeof data!=="object")return;
    for(const k of ["left","right","fire","boost"])p.input[k]=!!data[k];
    if(data.boost && Date.now()>p.boostUntil){p.boostUntil=Date.now()+1800;p.invuln=.25;}
  });
  socket.on("startGame",()=>{const r=roomFor(socket);if(!r)return;r.started=true;r.score=0;r.wave=1;r.enemies=[];r.bullets=[];r.enemyBullets=[];r.spawnIn=.7;
    for(const p of r.players.values()){p.hp=100;p.alive=true;p.score=0;p.x=160+Math.random()*640;p.y=510;}
    io.to(r.id).emit("notice",{type:"info",text:"بدأت المهمة! اتعاونوا لتدمير الأعداء."});emitState(r);});
  socket.on("disconnect",()=>leaveRoom(socket));
});

// Authoritative room simulation: clients send controls only; server owns movement,
// enemy health, bullet hits, waves, score, and enemy attacks.
let last=Date.now();
setInterval(()=>{
  const now=Date.now(),dt=Math.min(.05,(now-last)/1000);last=now;
  for(const r of rooms.values()){
    if(!r.started)continue;
    const alive=[...r.players.values()].filter(p=>p.alive);
    if(!alive.length){r.started=false;io.to(r.id).emit("notice",{type:"over",text:"انتهت الجولة — اضغطوا ابدأ للعب من جديد"});emitState(r);continue;}
    for(const p of alive){
      const speed=p.input.boost&&p.boostUntil>now?430:270;
      p.x=Math.max(22,Math.min(W-22,p.x+((p.input.right?1:0)-(p.input.left?1:0))*speed*dt));
      if(p.input.fire && now-p.lastShot>190){p.lastShot=now;r.bullets.push({id:crypto.randomUUID(),owner:p.id,x:p.x,y:p.y-20,vy:-520});}
    }
    r.spawnIn-=dt;
    if(r.spawnIn<=0 && r.enemies.length<12){
      const tough=Math.random()<Math.min(.45,.08+r.wave*.025),hp=(tough?75:32)+r.wave*5;
      r.enemies.push({id:r.nextEnemy++,x:rand(35,W-35),y:-25,r:tough?23:15,hp,maxHp:hp,vy:70+r.wave*5,type:tough?"tank":"scout",shot:rand(1.2,3)});
      r.spawnIn=Math.max(.32,1.25-r.wave*.045);
    }
    for(const e of r.enemies){e.y+=e.vy*dt;e.shot-=dt;if(e.shot<=0&&e.y>0){r.enemyBullets.push({id:crypto.randomUUID(),x:e.x,y:e.y+e.r,vy:210+r.wave*4});e.shot=rand(1.5,3.1);}}
    for(const b of r.bullets)b.y+=b.vy*dt;
    for(const b of r.enemyBullets)b.y+=b.vy*dt;
    for(const b of r.bullets){
      const e=r.enemies.find(e=>!e.dead&&Math.hypot(e.x-b.x,e.y-b.y)<e.r+6);
      if(e){e.hp-=18;e.dead=true;b.dead=true;if(e.hp>0)e.dead=false;else{e.dead=true;r.score+=e.type==="tank"?35:15;const p=r.players.get(b.owner);if(p)p.score+=e.type==="tank"?35:15;}}
    }
    for(const b of r.enemyBullets){
      for(const p of alive){if(Math.hypot(p.x-b.x,p.y-b.y)<21){p.hp-=18;b.dead=true;if(p.hp<=0){p.hp=0;p.alive=false;io.to(r.id).emit("notice",{type:"info",text:`${p.name} خرج من الجولة`});}break;}}
    }
    for(const e of r.enemies){if(e.y>H+40)e.dead=true;}
    r.bullets=r.bullets.filter(b=>!b.dead&&b.y>-30);
    r.enemyBullets=r.enemyBullets.filter(b=>!b.dead&&b.y<H+30);
    r.enemies=r.enemies.filter(e=>!e.dead);
    if(r.score>=r.wave*200){r.wave++;io.to(r.id).emit("notice",{type:"info",text:`الموجة ${r.wave}! الأعداء أسرع وأقوى`});}
    emitState(r);
  }
},1000/30);
server.listen(PORT,()=>console.log(`Star Hunter Online running on http://localhost:${PORT}`));
